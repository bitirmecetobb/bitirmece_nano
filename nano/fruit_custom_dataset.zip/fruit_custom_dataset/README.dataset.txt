# fruits > 2024-02-27 5:22pm
https://universe.roboflow.com/fruits-kbvvh/fruits-firff

Provided by a Roboflow user
License: Public Domain

