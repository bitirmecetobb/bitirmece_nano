# fruits > 2024-03-17 5:37pm
https://universe.roboflow.com/fruits-kbvvh/fruits-firff

Provided by a Roboflow user
License: Public Domain

